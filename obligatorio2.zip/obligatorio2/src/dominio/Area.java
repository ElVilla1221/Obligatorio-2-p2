package dominio;
import java.io.Serializable;
import java.util.*;
//Lucas Villamil (352138) y Dante Puerto (360160) 

public class Area implements Serializable, Comparable<Area>{
    private String nombre;
    private int presupuestoInicial;
    private int presupuestoDisponible;
    private int presupuestoGastado;
    private String descripcion;
    private ArrayList<Empleado> listaEmpleados;
    public Area(String unNombre, int unPresupuesto, String unaDescripcion){
        this.nombre=unNombre;
        this.presupuestoInicial=unPresupuesto;
        this.presupuestoDisponible=unPresupuesto;
        this.descripcion=unaDescripcion;
        listaEmpleados=new ArrayList<>();
    }
    public String getNombre() {
        return nombre;
    }

    public int getPresupuestoInicial() {
        return presupuestoInicial;
    }
    
    public int getPresupuestoDisponible() {
        return presupuestoDisponible;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public void setPresupuestoDisponible(int presupuestoDisponible) {
        this.presupuestoDisponible = presupuestoDisponible;
    }

    public int getPresupuestoGastado() {
        return presupuestoGastado;
    }

    public void setPresupuestoGastado(int presupuestoGastado) {
        this.presupuestoGastado = presupuestoGastado;
    }
    
    public ArrayList<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }
    public void agregarEmpleadoAlArea(Empleado emp){
        listaEmpleados.add(emp);
        Collections.sort(listaEmpleados);
        this.presupuestoDisponible-=emp.getSueldoMensual()*12;
        setPresupuestoGastado(this.presupuestoInicial-this.presupuestoDisponible);
    }
    public void recibirMovimiento(Empleado emp,int mes){
        listaEmpleados.add(emp);
        Collections.sort(listaEmpleados);
        this.presupuestoDisponible-=emp.getSueldoMensual()*(13-mes);
        setPresupuestoGastado(this.presupuestoInicial-this.presupuestoDisponible);
 
    }
    public boolean areaVacia(){
        return this.getListaEmpleados().isEmpty();
    }
    @Override
    public int compareTo(Area a) {
        return this.getNombre().compareToIgnoreCase(a.getNombre());
    }
    public boolean equals(Area a){
        return this.getNombre().equalsIgnoreCase(a.getNombre());
    }
    @Override
    public String toString() {
        return nombre;
    }
    public int darPorcentajeDePresupuesto(){
        return (this.presupuestoGastado*100) /this.getPresupuestoInicial();
    }
}
