package interfaz;
import dominio.*;
import java.util.*;
import javax.swing.JOptionPane;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class VentanaModificarManagers extends javax.swing.JFrame implements Observer {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaModificarManagers.class.getName());

    public VentanaModificarManagers(Sistema sis) {
        initComponents();
        modelo=sis;
        modelo.addObserver(this);
        setTitle("Modificar manager");
        setAlwaysOnTop(true);
        cargarLista();
        
    }
    public void limpiarCampos(){
        campoNombre.setText("");
        campoCedula.setText("");
        campoCelular.setText("");
        campoAnt.setText("");
        campoACargo.setText("");
    }
    public void cargarLista(){
        listaManagers.setListData(modelo.getListaManagers().toArray());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaManagers = new javax.swing.JList();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        botonModificar = new javax.swing.JButton();
        campoNombre = new javax.swing.JLabel();
        campoCedula = new javax.swing.JLabel();
        campoAnt = new javax.swing.JLabel();
        campoCelular = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        campoACargo = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        listaManagers.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaManagers.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaManagers.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaManagersValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(listaManagers);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(30, 70, 190, 310);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Lista de managers:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(30, 20, 190, 40);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Nombre: ");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(300, 50, 100, 50);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Cédula:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(300, 110, 100, 50);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Celular:");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(300, 170, 100, 50);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Empleados a cargo:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(300, 290, 150, 50);

        botonModificar.setBackground(new java.awt.Color(0, 0, 204));
        botonModificar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonModificar.setForeground(new java.awt.Color(255, 255, 255));
        botonModificar.setText("Modificar");
        botonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModificarActionPerformed(evt);
            }
        });
        jPanel1.add(botonModificar);
        botonModificar.setBounds(440, 360, 140, 40);

        campoNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoNombre);
        campoNombre.setBounds(410, 50, 320, 40);

        campoCedula.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoCedula);
        campoCedula.setBounds(410, 110, 320, 40);

        campoAnt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoAnt);
        campoAnt.setBounds(410, 230, 290, 40);

        campoCelular.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoCelular);
        campoCelular.setBounds(410, 170, 300, 40);

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Antigüedad:");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(300, 230, 100, 50);

        campoACargo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoACargo);
        campoACargo.setBounds(450, 290, 180, 40);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 792, 460);
    }// </editor-fold>//GEN-END:initComponents

    private void botonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModificarActionPerformed
        Manager man=(Manager)listaManagers.getSelectedValue();
        if(man!=null){
            if(campoCelular.getText().equals("")){
                JOptionPane.showMessageDialog(this,"LA DESCRIPCIÓN NO PUEDE ESTAR VACÍA","ERROR AL MODIFICAR",2);
            }else{
                man.setCelular(campoCelular.getText());
                modelo.modificacion();
                cargarLista();
                limpiarCampos();
            }
        }
    }//GEN-LAST:event_botonModificarActionPerformed

    private void listaManagersValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaManagersValueChanged
        Manager man=(Manager)listaManagers.getSelectedValue();
        if(man!=null){
            campoNombre.setText(man.getNombre());
            campoCedula.setText(man.getCedula());
            campoCelular.setText(man.getCelular());
            campoAnt.setText(man.getAntiguedad()+"");
            campoACargo.setText(man.getEmpleadosACargo().size()+"");
        }
    }//GEN-LAST:event_listaManagersValueChanged

    @Override
    public void update(Observable o, Object arg) {
        Manager man=(Manager)listaManagers.getSelectedValue();
        cargarLista();
        if(man!=null){
            for(int i=0;i<modelo.getListaManagers().size();i++){
                if(man.equals(modelo.getListaManagers().get(i))){
                    listaManagers.setSelectedIndex(i);
                }
            }
        }
    }
    private Sistema modelo;

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonModificar;
    private javax.swing.JLabel campoACargo;
    private javax.swing.JLabel campoAnt;
    private javax.swing.JLabel campoCedula;
    private javax.swing.JTextField campoCelular;
    private javax.swing.JLabel campoNombre;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList listaManagers;
    // End of variables declaration//GEN-END:variables
}
