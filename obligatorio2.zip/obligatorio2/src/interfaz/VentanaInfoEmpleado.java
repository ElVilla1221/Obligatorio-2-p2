package interfaz;
import dominio.*;

public class VentanaInfoEmpleado extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaInfoEmpleado.class.getName());
    private Empleado empleado;
    public VentanaInfoEmpleado(Empleado emp) {
        initComponents();
        empleado=emp;
        setAlwaysOnTop(true);
        setTitle("Información de "+ empleado.getNombre());
        cargarInfo();
    }
    public void cargarInfo(){
        campoNombre.setText("Nombre: "+empleado.getNombre());
        campoSueldo.setText("Sueldo: "+empleado.getSueldoMensual());
        campoCedula.setText("Cédula: "+empleado.getCedula());
        campoCelular.setText("Celular: "+empleado.getCelular());
        campoArea.setText("Área: "+empleado.getArea());
        campoManager.setText("Manager: "+empleado.getManager());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        campoNombre = new javax.swing.JLabel();
        campoManager = new javax.swing.JLabel();
        campoSueldo = new javax.swing.JLabel();
        campoCedula = new javax.swing.JLabel();
        campoCelular = new javax.swing.JLabel();
        campoArea = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        campoNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoNombre.setText("jLabel1");
        getContentPane().add(campoNombre);
        campoNombre.setBounds(20, 30, 700, 50);

        campoManager.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoManager.setText("jLabel1");
        getContentPane().add(campoManager);
        campoManager.setBounds(20, 410, 700, 50);

        campoSueldo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoSueldo.setText("jLabel1");
        getContentPane().add(campoSueldo);
        campoSueldo.setBounds(20, 100, 700, 50);

        campoCedula.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoCedula.setText("jLabel1");
        getContentPane().add(campoCedula);
        campoCedula.setBounds(20, 180, 700, 50);

        campoCelular.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoCelular.setText("jLabel1");
        getContentPane().add(campoCelular);
        campoCelular.setBounds(20, 260, 700, 50);

        campoArea.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        campoArea.setText("jLabel1");
        getContentPane().add(campoArea);
        campoArea.setBounds(20, 340, 700, 50);

        setBounds(0, 0, 771, 517);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel campoArea;
    private javax.swing.JLabel campoCedula;
    private javax.swing.JLabel campoCelular;
    private javax.swing.JLabel campoManager;
    private javax.swing.JLabel campoNombre;
    private javax.swing.JLabel campoSueldo;
    // End of variables declaration//GEN-END:variables
}
