package interfaz;
import dominio.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.*;

public class VentanaReporteDeAreas extends javax.swing.JFrame implements Observer{
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaReporteDeAreas.class.getName());
    public VentanaReporteDeAreas(Sistema sis) {
        initComponents();
        listaAreas.setModel(new DefaultListModel());
        modelo=sis;
        modelo.addObserver(this);
        setAlwaysOnTop(true);
        setTitle("Estado de áreas");
        cargarLista();
        listaAreas.setCellRenderer(new DefaultListCellRenderer(){
            @Override
            public Component getListCellRendererComponent(JList<?> lista, Object valor, int indice, boolean seleccionado,boolean cellHasFocus){
                Component c = super.getListCellRendererComponent(lista, valor, indice, seleccionado, cellHasFocus);
                Area area=(Area) valor;
                Color col;
                if(area.darPorcentajeDePresupuesto()>90){
                    col= Color.RED;
                }else if(area.darPorcentajeDePresupuesto()>=70){
                    col= Color.YELLOW;
                }else{
                    col= Color.LIGHT_GRAY;
                }
                if(seleccionado){
                    col=new Color(0,120,215);
                }
                JLabel labelFila =(JLabel)c;
                labelFila.setBackground(col);
                labelFila.setForeground(Color.BLACK);
                labelFila.setBorder(BorderFactory.createLineBorder(Color.GRAY,5));
                return labelFila;
                
            }
        });
    }
    public void cargarLista(){
        listaAreas.setListData(modelo.getListaAreas().toArray());
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaAreas = new javax.swing.JList();
        labelArea = new javax.swing.JLabel();
        panelEmpleados = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        listaAreas.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        listaAreas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaAreas.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaAreas.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaAreasValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(listaAreas);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(40, 80, 160, 240);
        jPanel1.add(labelArea);
        labelArea.setBounds(330, 10, 250, 30);

        panelEmpleados.setLayout(new java.awt.GridLayout(0, 3, 7, 7));
        jPanel1.add(panelEmpleados);
        panelEmpleados.setBounds(280, 80, 450, 240);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 811, 414);
    }// </editor-fold>//GEN-END:initComponents

    private void listaAreasValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaAreasValueChanged
        Area area=(Area)listaAreas.getSelectedValue();
        panelEmpleados.removeAll();
        panelEmpleados.revalidate();
        panelEmpleados.repaint();
        if(area!=null){
            labelArea.setText(area.getNombre()+" "+area.darPorcentajeDePresupuesto()+"%");
            for(int i=0;i<area.getListaEmpleados().size();i++){
                Empleado emp=area.getListaEmpleados().get(i);
                JButton nuevo = new JButton(emp.getNombre());  
                nuevo.setMargin(new Insets(5, 5, 5, 5));  
                if(area.getListaEmpleados().size()==1){
                    nuevo.setBackground(Color.BLACK);
                }else{
                    float t=(float) i/(area.getListaEmpleados().size()-1);
                    int azul=(int)(t*255);  
                    nuevo.setBackground(new Color(0,0,azul));
                }
                nuevo.setForeground(Color.WHITE);   
                nuevo.addActionListener(new EmpleadosListener(emp));  
                panelEmpleados.add(nuevo);  
            }
        } 
    }//GEN-LAST:event_listaAreasValueChanged
    class EmpleadosListener implements ActionListener{
        private Empleado empleado;
        public EmpleadosListener(Empleado emp){
            empleado=emp;
        }

        @Override
        public void actionPerformed(ActionEvent e) {
            VentanaInfoEmpleado vent = new VentanaInfoEmpleado(empleado);
            vent.setVisible(true);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel labelArea;
    private javax.swing.JList listaAreas;
    private javax.swing.JPanel panelEmpleados;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;

    @Override
    public void update(Observable o, Object arg) {
        Area area =(Area)listaAreas.getSelectedValue();
        cargarLista();
        listaAreas.repaint();
        if(area != null){
            for(int i=0;i<modelo.getListaAreas().size();i++){
                if(area.equals(modelo.getListaAreas().get(i))){
                    listaAreas.setSelectedIndex(i);
                    panelEmpleados.removeAll();
                    labelArea.setText(area.getNombre()+" "+area.darPorcentajeDePresupuesto()+"%");
                    for(int j=0;j<area.getListaEmpleados().size();j++){
                        Empleado emp=area.getListaEmpleados().get(j);
                        JButton nuevo = new JButton(emp.getNombre());  
                        nuevo.setMargin(new Insets(5, 5, 5, 5));  
                        if(area.getListaEmpleados().size()==1){
                            nuevo.setBackground(Color.BLACK);
                        }else{
                            float t=(float) j/(area.getListaEmpleados().size()-1);
                            int azul=(int)(t*255);  
                            nuevo.setBackground(new Color(0,0,azul));
                        }
                        nuevo.setForeground(Color.WHITE);   
                        nuevo.addActionListener(new EmpleadosListener(emp));  
                        panelEmpleados.add(nuevo);  
                    }
                }
            }
        }
    }
}
