package interfaz;
import dominio.*;
import java.awt.Image;
import java.awt.event.KeyEvent;
import javax.swing.*;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class VentanaMenu extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaMenu.class.getName());

    public VentanaMenu(Sistema sistema) {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("ERP Empresarial");
        modelo=sistema;
        ImageIcon img =(ImageIcon)labelFondo.getIcon();
        imagenFondo = img.getImage().getScaledInstance(labelFondo.getWidth(),labelFondo.getHeight(), Image.SCALE_SMOOTH);
        labelFondo.setIcon(new ImageIcon(imagenFondo));
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelFondo = new javax.swing.JPanel();
        labelFondo = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        menuAreas = new javax.swing.JMenu();
        altaAreas = new javax.swing.JMenuItem();
        bajaAreas = new javax.swing.JMenuItem();
        modificacionAreas = new javax.swing.JMenuItem();
        realizarMovimiento = new javax.swing.JMenuItem();
        menuManagers = new javax.swing.JMenu();
        altaManagers = new javax.swing.JMenuItem();
        bajaManagers = new javax.swing.JMenuItem();
        modificacionManagers = new javax.swing.JMenuItem();
        menuEmpleados = new javax.swing.JMenu();
        altaEmpleados = new javax.swing.JMenuItem();
        menuReportes = new javax.swing.JMenu();
        menuRepInteligente = new javax.swing.JMenuItem();
        menuEstadoAreas = new javax.swing.JMenuItem();
        menuRepMovimientos = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 102));
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                formComponentResized(evt);
            }
        });
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });

        panelFondo.setBackground(new java.awt.Color(255, 51, 51));

        labelFondo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/fondoMenu.jpg"))); // NOI18N

        javax.swing.GroupLayout panelFondoLayout = new javax.swing.GroupLayout(panelFondo);
        panelFondo.setLayout(panelFondoLayout);
        panelFondoLayout.setHorizontalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(labelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panelFondoLayout.setVerticalGroup(
            panelFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(labelFondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        getContentPane().add(panelFondo, java.awt.BorderLayout.CENTER);

        menuAreas.setText("Areas");

        altaAreas.setText("Alta");
        altaAreas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                altaAreasActionPerformed(evt);
            }
        });
        menuAreas.add(altaAreas);

        bajaAreas.setText("Baja");
        bajaAreas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bajaAreasActionPerformed(evt);
            }
        });
        menuAreas.add(bajaAreas);

        modificacionAreas.setText("Modificación");
        modificacionAreas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificacionAreasActionPerformed(evt);
            }
        });
        menuAreas.add(modificacionAreas);

        realizarMovimiento.setText("Realizar movimiento");
        realizarMovimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                realizarMovimientoActionPerformed(evt);
            }
        });
        menuAreas.add(realizarMovimiento);

        jMenuBar1.add(menuAreas);

        menuManagers.setText("Managers");

        altaManagers.setText("Alta");
        altaManagers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                altaManagersActionPerformed(evt);
            }
        });
        menuManagers.add(altaManagers);

        bajaManagers.setText("Baja");
        bajaManagers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bajaManagersActionPerformed(evt);
            }
        });
        menuManagers.add(bajaManagers);

        modificacionManagers.setText("Modificación");
        modificacionManagers.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificacionManagersActionPerformed(evt);
            }
        });
        menuManagers.add(modificacionManagers);

        jMenuBar1.add(menuManagers);

        menuEmpleados.setText("Empleados");

        altaEmpleados.setText("Alta");
        altaEmpleados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                altaEmpleadosActionPerformed(evt);
            }
        });
        menuEmpleados.add(altaEmpleados);

        jMenuBar1.add(menuEmpleados);

        menuReportes.setText("Reportes");

        menuRepInteligente.setText("Reporte inteligente");
        menuRepInteligente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuRepInteligenteActionPerformed(evt);
            }
        });
        menuReportes.add(menuRepInteligente);

        menuEstadoAreas.setText("Estado de áreas");
        menuEstadoAreas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuEstadoAreasActionPerformed(evt);
            }
        });
        menuReportes.add(menuEstadoAreas);

        menuRepMovimientos.setText("Reporte de movimientos");
        menuRepMovimientos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menuRepMovimientosActionPerformed(evt);
            }
        });
        menuReportes.add(menuRepMovimientos);

        jMenuBar1.add(menuReportes);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formComponentResized(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentResized
        ajustarImagenFondo();
    }//GEN-LAST:event_formComponentResized

    private void bajaAreasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bajaAreasActionPerformed
        VentanaBajaAreas vent = new VentanaBajaAreas(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_bajaAreasActionPerformed

    private void modificacionAreasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificacionAreasActionPerformed
        VentanaModificarAreas vent = new VentanaModificarAreas(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_modificacionAreasActionPerformed

    private void altaAreasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_altaAreasActionPerformed
        VentanaAltaAreas vent = new VentanaAltaAreas(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_altaAreasActionPerformed

    private void altaManagersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_altaManagersActionPerformed
        VentanaAltaManagers vent = new VentanaAltaManagers(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_altaManagersActionPerformed

    private void realizarMovimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_realizarMovimientoActionPerformed
        VentanaMovimiento vent = new VentanaMovimiento(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_realizarMovimientoActionPerformed

    private void altaEmpleadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_altaEmpleadosActionPerformed
        VentanaAltaEmpleados vent = new VentanaAltaEmpleados(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_altaEmpleadosActionPerformed

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_F1){
            JOptionPane.showMessageDialog(null,"Trabajo realizado por: Dante Puerto (360160) y Lucas Villamil (352138)","Autores:",1);
        }
    }//GEN-LAST:event_formKeyPressed

    private void menuRepInteligenteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRepInteligenteActionPerformed
        VentanaReporteInteligente vent = new VentanaReporteInteligente(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_menuRepInteligenteActionPerformed

    private void menuRepMovimientosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuRepMovimientosActionPerformed
        VentanaReporteMovimientos vent = new VentanaReporteMovimientos(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_menuRepMovimientosActionPerformed

    private void bajaManagersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bajaManagersActionPerformed
        VentanaBajaManagers vent = new VentanaBajaManagers(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_bajaManagersActionPerformed

    private void modificacionManagersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificacionManagersActionPerformed
        VentanaModificarManagers vent = new VentanaModificarManagers(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_modificacionManagersActionPerformed

    private void menuEstadoAreasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menuEstadoAreasActionPerformed
        VentanaReporteDeAreas vent = new VentanaReporteDeAreas(modelo);
        vent.setVisible(true);
    }//GEN-LAST:event_menuEstadoAreasActionPerformed
    public void ajustarImagenFondo(){
        if(labelFondo.getWidth() > 0 && labelFondo.getHeight() > 0){
            Image imagenAjustada = imagenFondo.getScaledInstance(labelFondo.getWidth(),labelFondo.getHeight(), Image.SCALE_SMOOTH);
            labelFondo.setIcon(new ImageIcon(imagenAjustada));
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem altaAreas;
    private javax.swing.JMenuItem altaEmpleados;
    private javax.swing.JMenuItem altaManagers;
    private javax.swing.JMenuItem bajaAreas;
    private javax.swing.JMenuItem bajaManagers;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JLabel labelFondo;
    private javax.swing.JMenu menuAreas;
    private javax.swing.JMenu menuEmpleados;
    private javax.swing.JMenuItem menuEstadoAreas;
    private javax.swing.JMenu menuManagers;
    private javax.swing.JMenuItem menuRepInteligente;
    private javax.swing.JMenuItem menuRepMovimientos;
    private javax.swing.JMenu menuReportes;
    private javax.swing.JMenuItem modificacionAreas;
    private javax.swing.JMenuItem modificacionManagers;
    private javax.swing.JPanel panelFondo;
    private javax.swing.JMenuItem realizarMovimiento;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;
    private Image imagenFondo;
}
