package interfaz;
import java.util.*;
import dominio.*;

public class VentanaBajaManagers extends javax.swing.JFrame implements Observer {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaBajaManagers.class.getName());

    public VentanaBajaManagers(Sistema sis) {
        initComponents();
        modelo=sis;
        modelo.addObserver(this);
        setAlwaysOnTop(true);
        setTitle("Eliminar manager");
        cargarLista();
        
    }
    public void cargarLista(){
        listaVacios.setListData(modelo.darManagersSinEmpleados().toArray());
    }
    public void limpiarCampos(){
        campoNombre.setText("");
        campoCedula.setText("");
        campoCelular.setText("");
        campoAnt.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaVacios = new javax.swing.JList();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        botonEliminar = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        campoAnt = new javax.swing.JLabel();
        campoNombre = new javax.swing.JLabel();
        campoCedula = new javax.swing.JLabel();
        campoCelular = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        listaVacios.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaVacios.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaVacios.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaVaciosValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(listaVacios);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(30, 70, 200, 280);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        jLabel1.setText("Managers sin empleados:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(30, 16, 230, 40);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Antigüedad:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(300, 230, 100, 50);

        botonEliminar.setBackground(new java.awt.Color(204, 0, 0));
        botonEliminar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonEliminar.setForeground(new java.awt.Color(255, 255, 255));
        botonEliminar.setText("Eliminar");
        botonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(botonEliminar);
        botonEliminar.setBounds(420, 320, 140, 40);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Nombre: ");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(300, 50, 100, 50);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Cédula:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(300, 110, 100, 50);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Celular:");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(300, 170, 100, 50);

        campoAnt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoAnt);
        campoAnt.setBounds(410, 230, 270, 40);

        campoNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoNombre);
        campoNombre.setBounds(410, 50, 270, 40);

        campoCedula.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoCedula);
        campoCedula.setBounds(410, 110, 270, 40);

        campoCelular.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoCelular);
        campoCelular.setBounds(410, 170, 270, 40);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 758, 452);
    }// </editor-fold>//GEN-END:initComponents

    private void botonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEliminarActionPerformed
        Manager man = (Manager)listaVacios.getSelectedValue();
        if(man!=null){
            modelo.borrarManager(man);
        }
    }//GEN-LAST:event_botonEliminarActionPerformed

    private void listaVaciosValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaVaciosValueChanged
        Manager man= (Manager)listaVacios.getSelectedValue();
        if(man!=null){
            campoNombre.setText(man.getNombre());
            campoCedula.setText(man.getCedula());
            campoCelular.setText(man.getCelular());
            campoAnt.setText(man.getAntiguedad()+"");
        }
    }//GEN-LAST:event_listaVaciosValueChanged


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonEliminar;
    private javax.swing.JLabel campoAnt;
    private javax.swing.JLabel campoCedula;
    private javax.swing.JLabel campoCelular;
    private javax.swing.JLabel campoNombre;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList listaVacios;
    // End of variables declaration//GEN-END:variables

    @Override
    public void update(Observable o, Object arg) {
        limpiarCampos();
        Manager man= (Manager)listaVacios.getSelectedValue();
        cargarLista();
        if(man!=null){
            for(int i=0;i<modelo.darManagersSinEmpleados().size();i++){
                if(man.equals(modelo.darManagersSinEmpleados().get(i))){
                    listaVacios.setSelectedIndex(i);
                }
            }
        }
    }
    private Sistema modelo;
}
