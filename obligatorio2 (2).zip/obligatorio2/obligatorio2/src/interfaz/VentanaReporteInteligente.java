package interfaz;
import dominio.*;
import java.util.*;
import javax.swing.*;
import servicios.*;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class VentanaReporteInteligente extends javax.swing.JFrame implements Observer{
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaReporteInteligente.class.getName());

    public VentanaReporteInteligente(Sistema sis) {
        initComponents();
        setAlwaysOnTop(true);
        setTitle("Reporte inteligente");
        iconoTick.setVisible(false);
        iconoReloj.setVisible(false);
        modelo=sis;
        modelo.addObserver(this);
        cargarListas();
        listaEmpleados.setListData(new Object[0]);
        campoRespuesta.setLineWrap(true);
        campoRespuesta.setWrapStyleWord(true);
    }
    public void cargarListas(){
        listaOrigen.setListData(modelo.getListaAreas().toArray());
        listaDestino.setListData(modelo.getListaAreas().toArray());
    }
    public void cargarListaEmpleados(Area a){
        listaEmpleados.setListData(a.getListaEmpleados().toArray());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaOrigen = new javax.swing.JList();
        jScrollPane3 = new javax.swing.JScrollPane();
        listaDestino = new javax.swing.JList();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaEmpleados = new javax.swing.JList();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        botonGenerar = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        campoRespuesta = new javax.swing.JTextArea();
        iconoReloj = new javax.swing.JLabel();
        iconoTick = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        listaOrigen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaOrigen.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaOrigen.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaOrigenValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(listaOrigen);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(20, 50, 150, 210);

        listaDestino.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaDestino.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaDestino.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaDestinoValueChanged(evt);
            }
        });
        jScrollPane3.setViewportView(listaDestino);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(300, 50, 150, 210);

        listaEmpleados.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaEmpleados.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listaEmpleados);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(550, 50, 150, 210);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Área de origen:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 0, 150, 50);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Área de destino:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(300, 0, 150, 50);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Empleados:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(550, 0, 150, 50);

        botonGenerar.setBackground(new java.awt.Color(0, 204, 204));
        botonGenerar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonGenerar.setForeground(new java.awt.Color(0, 0, 0));
        botonGenerar.setText("Generar reporte");
        botonGenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGenerarActionPerformed(evt);
            }
        });
        jPanel1.add(botonGenerar);
        botonGenerar.setBounds(260, 290, 150, 40);

        campoRespuesta.setColumns(20);
        campoRespuesta.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        campoRespuesta.setRows(5);
        jScrollPane4.setViewportView(campoRespuesta);

        jPanel1.add(jScrollPane4);
        jScrollPane4.setBounds(20, 350, 740, 210);

        iconoReloj.setIcon(new javax.swing.ImageIcon(getClass().getResource("/gifReloj.gif"))); // NOI18N
        jPanel1.add(iconoReloj);
        iconoReloj.setBounds(420, 290, 40, 40);

        iconoTick.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenTick.png"))); // NOI18N
        jPanel1.add(iconoTick);
        iconoTick.setBounds(420, 290, 40, 40);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 782, 688);
    }// </editor-fold>//GEN-END:initComponents

    private void listaOrigenValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaOrigenValueChanged
        Area orig = (Area)listaOrigen.getSelectedValue();
        Area dest = (Area)listaDestino.getSelectedValue();
        if(orig!=null && dest!=null){
            if(dest.equals(orig)){
                listaOrigen.clearSelection();
            }
        }
        if(orig!=null){
            cargarListaEmpleados(orig);
        }else{
            listaEmpleados.setListData(new Object[0]);
        }
    }//GEN-LAST:event_listaOrigenValueChanged

    private void listaDestinoValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaDestinoValueChanged
        Area orig = (Area)listaOrigen.getSelectedValue();
        Area dest = (Area)listaDestino.getSelectedValue();
        if(orig!=null && dest!=null){
            if(dest.equals(orig)){
                listaDestino.clearSelection();
            }
        }
    }//GEN-LAST:event_listaDestinoValueChanged

    private void botonGenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGenerarActionPerformed
        Empleado emp= (Empleado)listaEmpleados.getSelectedValue();
        Area origen =(Area)listaOrigen.getSelectedValue();
        Area dest=(Area)listaDestino.getSelectedValue();
        if(emp != null && origen != null && dest !=null){
            campoRespuesta.setText("");
        iconoTick.setVisible(false);
        iconoReloj.setVisible(true);
        SwingWorker<String, Void> worker = new SwingWorker<String, Void>(){
            @Override
            public String doInBackground() throws Exception{
                ConectarAIA con = new ConectarAIA();
                ArchivoLectura cv= new ArchivoLectura("cvs/CV"+emp.getCedula()+".txt");
                String curriculum="";
                while(cv.hayMasLineas()){
                    curriculum+=cv.linea();
                }
                cv.cerrar();
                String prompt = CrearPrompt.crearPrompt(origen, dest, curriculum, emp);
                String respJson = con.solicitarReporte(prompt);
                return con.obtenerRespuesta(respJson);
            }
            @Override
            public void done(){
                try{
                    String respFinal = get();  
                    campoRespuesta.setText(respFinal);
                    iconoReloj.setVisible(false);
                    iconoTick.setVisible(true);
                }catch(Exception e){
                    iconoReloj.setVisible(false);
                    JOptionPane.showMessageDialog(VentanaReporteInteligente.this,"NO SE HA PODIDO CONECTAR CON LA IA","ERROR AL CONECTAR CON LA IA", 0);
                }
            }
        };
        worker.execute();
        }
    }//GEN-LAST:event_botonGenerarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonGenerar;
    private javax.swing.JTextArea campoRespuesta;
    private javax.swing.JLabel iconoReloj;
    private javax.swing.JLabel iconoTick;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JList listaDestino;
    private javax.swing.JList listaEmpleados;
    private javax.swing.JList listaOrigen;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;

    @Override
    public void update(Observable o, Object arg) {
        Area area= (Area)listaOrigen.getSelectedValue();
        cargarListas();
        if(area!=null){
            for(int i=0;i<modelo.getListaAreas().size();i++){
                if(area.getNombre().equalsIgnoreCase(modelo.getListaAreas().get(i).getNombre())){
                    listaOrigen.setSelectedIndex(i);
                    cargarListaEmpleados(area);
                }
            }
        }
    }
}