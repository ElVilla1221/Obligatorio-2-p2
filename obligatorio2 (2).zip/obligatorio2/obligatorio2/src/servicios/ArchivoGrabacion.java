package servicios;
import java.io.*;
import java.util.*;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class ArchivoGrabacion implements Serializable {
    private Formatter out;
    public ArchivoGrabacion(String nombre){
        try {
            out = new Formatter(nombre);
        }
        catch(FileNotFoundException e){
            System.out.println("Error al crear el archivo");
        }
    }
    public ArchivoGrabacion(String nombre, boolean extender){
        try {
            FileWriter f = new FileWriter(nombre, extender);
            out = new Formatter(f);
        }
        catch(IOException e){
            System.out.println("Error al crear el archivo");
        }
    }
    public void grabarLinea(String linea){
        out.format("%s%n", linea);
    }
    public void cerrar(){
        out.close();
    }
}
