package servicios;
//Lucas Villamil (352138) y Dante Puerto (360160)
import java.io.*;
import java.net.*;
import com.google.gson.*;

public class ConectarAIA {
    public String solicitarReporte(String prompt) throws Exception{
        String apiKey=ClaveIA.getApiKey();
        URL url= new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key="+ apiKey);
        HttpURLConnection conexion=(HttpURLConnection)url.openConnection();
        conexion.setRequestMethod("POST");
        conexion.setRequestProperty("Content-Type","application/json; charset=UTF-8");
        conexion.setDoOutput(true);
        
        JsonObject parte= new JsonObject();
        parte.addProperty("text",prompt);
        JsonArray partes= new JsonArray();
        partes.add(parte);
        JsonObject contenido = new JsonObject();
        contenido.add("parts",partes);
        JsonArray contenidos= new JsonArray();
        contenidos.add(contenido);
        JsonObject raiz = new JsonObject();
        raiz.add("contents",contenidos);
        String json= raiz.toString();
        try(OutputStream os= conexion.getOutputStream()){
            os.write(json.getBytes("UTF-8"));
        }
        
        BufferedReader br= new BufferedReader(new InputStreamReader(conexion.getInputStream()));
        StringBuilder respuesta= new StringBuilder();
        String linea;
        while((linea=br.readLine()) != null){
            respuesta.append(linea);
        }
        br.close();
        return respuesta.toString();   
    }
    
    public String obtenerRespuesta(String json){
        JsonObject respuesta= JsonParser.parseString(json).getAsJsonObject();
        return respuesta.getAsJsonArray("candidates").get(0).getAsJsonObject().getAsJsonObject("content").getAsJsonArray("parts").get(0).getAsJsonObject().
                get("text").getAsString();
    }
}
