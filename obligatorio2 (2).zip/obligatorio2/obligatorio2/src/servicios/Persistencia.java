package servicios;
import java.io.*;
import dominio.*;
public class Persistencia {
    public static void serializar(Sistema sis){
        try{
            FileOutputStream arch = new FileOutputStream("sistema.ser");
            ObjectOutputStream grabar = new ObjectOutputStream(arch);
            grabar.writeObject(sis);
            grabar.close();
        }catch(IOException e){
            
        }
    }
    public static Sistema desSerializar(){
        try{
            FileInputStream arch = new FileInputStream("sistema.ser");
            ObjectInputStream leer = new ObjectInputStream(arch);
            Sistema sistema=(Sistema) leer.readObject();
            leer.close();
            return sistema;
        }catch(Exception e){
            return null;
        }
    }
}
