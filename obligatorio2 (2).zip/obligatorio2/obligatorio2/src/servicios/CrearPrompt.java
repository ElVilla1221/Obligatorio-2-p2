package servicios;
import dominio.*;
//Lucas Villamil (352138) y Dante Puerto (360160)
public class CrearPrompt {
    public static String crearPrompt(Area orig,Area dest,String textoCV,Empleado emp){
        return "Genera un reporte para decidir el movimiento del empleado "+emp.getNombre() +" de un area de la empresa a otra, indicando las ventajas "
                + "y las desventajas del movimiento (si las hay).\n "+""
                + "Area de origen: Nombre: "+orig.getNombre()+"Descripcion: "+orig.getDescripcion()+"\n"+
                "Area de destino: "+dest.getNombre()+" Descripción: "+dest.getDescripcion()+"\n"+
                "Curriculum del empleado: "+textoCV+"."+"\n"+
                "Tu respuesta va a ser desplegada en una ventana grafica swing, por lo que no utilizes astreiscos ni # ni nada para resaltar texto";
    }
}
