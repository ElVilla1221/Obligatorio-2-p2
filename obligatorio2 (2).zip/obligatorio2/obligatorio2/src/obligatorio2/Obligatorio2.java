package obligatorio2;
import interfaz.*;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class Obligatorio2 {

    public static void main(String[] args) {
        VentanaBienvenida vent= new VentanaBienvenida();
        vent.setVisible(true);
    }
    
}
