package dominio;
import java.io.Serializable;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class Empleado implements Serializable, Comparable<Empleado>{
    private String nombre;
    private int sueldoMensual;
    private String celular;
    private String cedula;
    private Manager manager;
    private Area area;
    public Empleado(String nombre, int sueldoMensual, String celular, String cedula, Manager manager, Area area) {
        this.nombre = nombre;
        this.sueldoMensual = sueldoMensual;
        this.celular = celular;
        this.cedula = cedula;
        this.manager = manager;
        this.area = area;
    }
    public String getNombre() {
        return nombre;
    }
    public int getSueldoMensual() {
        return sueldoMensual;
    }
    public String getCelular() {
        return celular;
    }
    public String getCedula() {
        return cedula;
    }
    public Manager getManager() {
        return manager;
    }
    public Area getArea() {
        return area;
    }
    public void setArea(Area area) {
        this.area = area;
    }
    @Override
    public int compareTo(Empleado emp) {
        return this.getSueldoMensual()-emp.getSueldoMensual();
    } 
    @Override
    public String toString() {
        return nombre;
    }
    
}
