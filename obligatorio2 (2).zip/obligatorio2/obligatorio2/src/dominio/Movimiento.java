package dominio;
import java.io.Serializable;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class Movimiento implements Serializable, Comparable<Movimiento>{
    private int mes;
    private Area origen;
    private Area destino;
    private Empleado empleado;

    public Movimiento(int mes, Area origen, Area destino, Empleado empleado) {
        this.mes = mes;
        this.origen = origen;
        this.destino = destino;
        this.empleado = empleado;
    }

    public int getMes() {
        return mes;
    }

    public Area getOrigen() {
        return origen;
    }

    public Area getDestino() {
        return destino;
    }

    public Empleado getEmpleado() {
        return empleado;
    }
    @Override
    public String toString() {
        return "Mes:" + mes + ", origen: " + origen + ", destino: " + destino + ", empleado: " + empleado + '}';
    }

    @Override
    public int compareTo(Movimiento mov) {
        return this.getMes()-mov.getMes();
    }
}
