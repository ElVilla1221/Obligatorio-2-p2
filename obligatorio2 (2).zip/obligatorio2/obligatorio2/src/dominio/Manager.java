package dominio;
import java.io.Serializable;
import java.util.*;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class Manager implements Serializable,Comparable<Manager>{
    private String nombre;
    private String cedula;
    private String celular;
    private int antiguedad;
    private ArrayList<Empleado> empleadosACargo;
    public Manager(String nombre, String cedula, String celular, int antiguedad) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.celular = celular;
        this.antiguedad = antiguedad;
        this.empleadosACargo = new ArrayList<>();
    }

    public String getNombre() {
        return nombre;
    }
    public String getCedula() {
        return cedula;
    }
    public String getCelular() {
        return celular;
    }
    public void setCelular(String celular) {
        this.celular = celular;
    }
    public int getAntiguedad() {
        return antiguedad;
    }
    public ArrayList<Empleado> getEmpleadosACargo() {
        return empleadosACargo;
    }

    public void agregarEmpleadoACargo(Empleado emp) {
        this.empleadosACargo.add(emp);
    }
    public boolean sinEmpleados(){
        return this.getEmpleadosACargo().isEmpty();
    }

    @Override
    public String toString() {
        return nombre;
    }

    @Override
    public int compareTo(Manager m) {
        return m.getAntiguedad()-this.getAntiguedad();
    }
    public boolean equals(Manager m){
        return this.getCedula().equalsIgnoreCase(m.getCedula());
    }
    
    
}
