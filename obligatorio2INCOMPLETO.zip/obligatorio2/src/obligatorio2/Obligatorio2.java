package obligatorio2;
import interfaz.*;

public class Obligatorio2 {

    public static void main(String[] args) {
        VentanaBienvenida vent= new VentanaBienvenida();
        vent.setVisible(true);
    }
    
}
