package servicios;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class ClaveIA {
    private static String apiKey;
    static{
        apiKey= System.getenv("ERP_API_KEY");
        if(apiKey==null || apiKey.equals("")){
            throw new RuntimeException("No se encontro la variable de entorno ERP_API_KEY");
        }
    }
}
