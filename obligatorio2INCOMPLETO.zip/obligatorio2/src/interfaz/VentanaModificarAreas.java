package interfaz;
import dominio.*;

public class VentanaModificarAreas extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaModificarAreas.class.getName());

    public VentanaModificarAreas(Sistema sistema) {
        initComponents();
        modelo=sistema;
        cargarLista();
    }
    public void cargarLista(){
        listaAreas.setListData(modelo.getListaAreas().toArray());
    }
    public void limpiarCampos(){
        contNombre.setText("");
        contDescripcion.setText("");
        contPresupuesto.setText("");
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaAreas = new javax.swing.JList();
        contPresupuesto = new javax.swing.JLabel();
        botonModificar = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        contNombre = new javax.swing.JLabel();
        contDescripcion = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(null);

        jPanel1.setLayout(null);

        listaAreas.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        listaAreas.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaAreas.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaAreasValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(listaAreas);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 80, 243, 270);

        contPresupuesto.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(contPresupuesto);
        contPresupuesto.setBounds(420, 270, 210, 42);

        botonModificar.setBackground(new java.awt.Color(0, 0, 153));
        botonModificar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        botonModificar.setForeground(new java.awt.Color(255, 255, 255));
        botonModificar.setText("Modificar");
        botonModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonModificarActionPerformed(evt);
            }
        });
        jPanel1.add(botonModificar);
        botonModificar.setBounds(390, 370, 160, 46);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Lista de áreas:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(20, 20, 197, 42);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setText("Nombre:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(300, 70, 90, 42);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setText("Descripcion:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(300, 170, 120, 42);

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel5.setText("Presupuesto:");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(300, 270, 120, 42);

        contNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(contNombre);
        contNombre.setBounds(420, 70, 200, 42);

        contDescripcion.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        contDescripcion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contDescripcionActionPerformed(evt);
            }
        });
        jPanel1.add(contDescripcion);
        contDescripcion.setBounds(430, 180, 250, 30);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(20, 0, 720, 460);

        setBounds(0, 0, 794, 507);
    }// </editor-fold>//GEN-END:initComponents

    private void listaAreasValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaAreasValueChanged
        Area area= (Area)listaAreas.getSelectedValue();
        if(area!=null){
            contNombre.setText(area.getNombre());
            contDescripcion.setText(area.getDescripcion());
            contPresupuesto.setText(area.getPresupuesto()+"");
        }
    }//GEN-LAST:event_listaAreasValueChanged

    private void botonModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonModificarActionPerformed
        Area area= (Area)listaAreas.getSelectedValue();
        if(area!=null){
            Area areaMod = new Area(area.getNombre(),area.getPresupuesto(),contDescripcion.getText());
            modelo.modificarArea(areaMod);
            cargarLista();
            limpiarCampos();
        }
    }//GEN-LAST:event_botonModificarActionPerformed

    private void contDescripcionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contDescripcionActionPerformed
 
    }//GEN-LAST:event_contDescripcionActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonModificar;
    private javax.swing.JTextField contDescripcion;
    private javax.swing.JLabel contNombre;
    private javax.swing.JLabel contPresupuesto;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList listaAreas;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;
}
