package interfaz;

import java.awt.Image;
import java.awt.event.*;
import javax.swing.*;

public class VentanaBienvenida extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaBienvenida.class.getName());

    public VentanaBienvenida() {
        initComponents();
        this.setLocationRelativeTo(null);
        ImageIcon img =(ImageIcon)labelImagen.getIcon();
        Image ajustarImg = img.getImage().getScaledInstance(labelImagen.getWidth(),labelImagen.getHeight(), Image.SCALE_SMOOTH);
        labelImagen.setIcon(new ImageIcon(ajustarImg));
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        labelImagen = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(null);

        labelImagen.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenERP.png"))); // NOI18N
        getContentPane().add(labelImagen);
        labelImagen.setBounds(0, 0, 480, 400);

        setSize(new java.awt.Dimension(471, 400));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        Timer timer = new Timer(4000, new ActionListener(){
            public void actionPerformed(ActionEvent e){
                dispose();
                VentanaComenzar vent= new VentanaComenzar();
                vent.setVisible(true);
            }
        });
        timer.setRepeats(false);
        timer.start();
    }//GEN-LAST:event_formWindowOpened
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel labelImagen;
    // End of variables declaration//GEN-END:variables
}
