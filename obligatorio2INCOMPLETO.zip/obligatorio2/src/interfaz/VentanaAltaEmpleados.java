package interfaz;
import java.util.*;
import dominio.*;

public class VentanaAltaEmpleados extends javax.swing.JFrame implements Observer{
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaAltaEmpleados.class.getName());

    public VentanaAltaEmpleados(Sistema sistema) {
        initComponents();
        modelo= sistema;
        cargarLista();
        setAlwaysOnTop(true);
        modelo.addObserver(this);
        
    }
    public void cargarLista(){
        listaEmpleados.setListData(modelo.getListaEmpleados().toArray());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaEmpleados = new javax.swing.JList();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        listaEmpleados.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaEmpleados.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listaEmpleados);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 60, 150, 270);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 609, 411);
    }// </editor-fold>//GEN-END:initComponents

    @Override
    public void update(Observable o, Object arg) {
    
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList listaEmpleados;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;
}
