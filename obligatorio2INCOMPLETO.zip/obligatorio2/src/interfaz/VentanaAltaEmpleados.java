package interfaz;
import java.util.*;
import dominio.*;
import java.io.File;
import javax.swing.JOptionPane;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class VentanaAltaEmpleados extends javax.swing.JFrame implements Observer{
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaAltaEmpleados.class.getName());

    public VentanaAltaEmpleados(Sistema sistema) {
        initComponents();
        setTitle("Agregar empleado");
        modelo= sistema;
        cargarListas();
        setAlwaysOnTop(true);
        modelo.addObserver(this);
        
    }
    public void cargarListas(){
        listaEmpleados.setListData(modelo.getListaEmpleados().toArray());
        listaAreas.setListData(modelo.getListaAreas().toArray());
        listaManagers.setListData(modelo.getListaManagers().toArray());
    }
    public void limpiarCampos(){
        campoSueldo.setText("");
        campoCedula.setText("");
        campoCelular.setText("");
        campoNombre.setText("");
        campoCurriculum.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaEmpleados = new javax.swing.JList();
        jLabel1 = new javax.swing.JLabel();
        labelManager = new javax.swing.JLabel();
        labelNombre = new javax.swing.JLabel();
        labelSueldo = new javax.swing.JLabel();
        labelArea = new javax.swing.JLabel();
        labelCedula = new javax.swing.JLabel();
        labelCelular = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        labelNombre2 = new javax.swing.JLabel();
        labelNombre3 = new javax.swing.JLabel();
        labelNombre4 = new javax.swing.JLabel();
        labelNombre5 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaAreas = new javax.swing.JList();
        labelNombre7 = new javax.swing.JLabel();
        labelNombre6 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        listaManagers = new javax.swing.JList();
        botonAgregar = new javax.swing.JButton();
        campoNombre = new javax.swing.JTextField();
        campoSueldo = new javax.swing.JTextField();
        campoCelular = new javax.swing.JTextField();
        campoCedula = new javax.swing.JTextField();
        labelNombre8 = new javax.swing.JLabel();
        campoCurriculum = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        listaEmpleados.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaEmpleados.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaEmpleados.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaEmpleadosValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(listaEmpleados);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 60, 150, 290);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Lista de empleados:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 20, 140, 30);

        labelManager.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(labelManager);
        labelManager.setBounds(190, 320, 130, 40);

        labelNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(labelNombre);
        labelNombre.setBounds(190, 40, 190, 40);

        labelSueldo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(labelSueldo);
        labelSueldo.setBounds(190, 90, 190, 40);

        labelArea.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(labelArea);
        labelArea.setBounds(190, 260, 130, 40);

        labelCedula.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(labelCedula);
        labelCedula.setBounds(190, 140, 180, 40);

        labelCelular.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(labelCelular);
        labelCelular.setBounds(190, 200, 190, 40);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setText("Agregar empleado:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(520, 0, 180, 40);

        labelNombre2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelNombre2.setText("Nombre:");
        jPanel1.add(labelNombre2);
        labelNombre2.setBounds(420, 50, 60, 40);

        labelNombre3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelNombre3.setText("Sueldo mensual:");
        jPanel1.add(labelNombre3);
        labelNombre3.setBounds(420, 100, 120, 40);

        labelNombre4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelNombre4.setText("Curriculum:");
        jPanel1.add(labelNombre4);
        labelNombre4.setBounds(420, 250, 110, 40);

        labelNombre5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelNombre5.setText("Manager:");
        jPanel1.add(labelNombre5);
        labelNombre5.setBounds(640, 290, 70, 40);

        listaAreas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaAreas.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(listaAreas);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(420, 330, 150, 150);

        labelNombre7.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelNombre7.setText("Celular:");
        jPanel1.add(labelNombre7);
        labelNombre7.setBounds(420, 200, 70, 40);

        labelNombre6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelNombre6.setText("Área:");
        jPanel1.add(labelNombre6);
        labelNombre6.setBounds(420, 290, 70, 40);

        listaManagers.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaManagers.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(listaManagers);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(640, 330, 160, 150);

        botonAgregar.setBackground(new java.awt.Color(0, 0, 153));
        botonAgregar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonAgregar.setForeground(new java.awt.Color(255, 255, 255));
        botonAgregar.setText("Agregar empleado");
        botonAgregar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonAgregarActionPerformed(evt);
            }
        });
        jPanel1.add(botonAgregar);
        botonAgregar.setBounds(530, 510, 160, 50);

        campoNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoNombre);
        campoNombre.setBounds(550, 50, 260, 30);

        campoSueldo.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoSueldo);
        campoSueldo.setBounds(550, 100, 260, 30);

        campoCelular.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoCelular);
        campoCelular.setBounds(550, 200, 260, 30);

        campoCedula.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoCedula);
        campoCedula.setBounds(550, 150, 260, 30);

        labelNombre8.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        labelNombre8.setText("Cédula:");
        jPanel1.add(labelNombre8);
        labelNombre8.setBounds(420, 150, 70, 40);

        campoCurriculum.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoCurriculum);
        campoCurriculum.setBounds(550, 250, 260, 30);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 880, 631);
    }// </editor-fold>//GEN-END:initComponents

    private void listaEmpleadosValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaEmpleadosValueChanged
        Empleado emp = (Empleado)listaEmpleados.getSelectedValue();
        if(emp!=null){
            labelNombre.setText("Nombre: "+emp.getNombre());
            labelSueldo.setText("Sueldo mensual: $"+emp.getSueldoMensual());
            labelCedula.setText("Cédula: "+emp.getCedula());
            labelCelular.setText("Celular: "+emp.getCelular());
            labelArea.setText("Área: "+emp.getArea());
            labelManager.setText("Manager: "+emp.getManager());
        }
    }//GEN-LAST:event_listaEmpleadosValueChanged

    private void botonAgregarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonAgregarActionPerformed
        Area area= (Area)listaAreas.getSelectedValue();
        Manager man = (Manager)listaManagers.getSelectedValue();
        String nombre= campoNombre.getText();
        String cedula= campoCedula.getText();
        String celular = campoCelular.getText();
        String curriculum = campoCurriculum.getText();
        if(nombre.equals("") || cedula.equals("") || celular.equals("") || curriculum.equals("")){
            JOptionPane.showMessageDialog(this,"POR FAVOR COMPLETE TODOS LOS CAMPOS ","ERROR AL INGRESAR",2);
            return;
        }
        try{
            int sueldo= Integer.parseInt(campoSueldo.getText());
            if(sueldo<0){
                JOptionPane.showMessageDialog(this,"INGRESE UN SUELDO VALIDO","ERROR AL INGRESAR",2);
                campoSueldo.setText("");
            }else if(!modelo.cedulaValida(cedula)){
                JOptionPane.showMessageDialog(this,"LA CÉDULA YA ESTÁ REGISTRADA EN EL SISTEMA","ERROR AL INGRESAR",2);
                campoCedula.setText("");
            }else if(area!=null && man!=null){
                if(modelo.puedoMover(sueldo, area,12)){
                    Empleado emp = new Empleado(nombre,sueldo,celular,cedula,man,area);
                    modelo.agregarEmpleado(emp);
                    modelo.agregarEmpleadoAlArea(area,emp);
                    File carpeta = new File(System.getProperty("user.dir")+File.separator+"cvs");
                    String nombreArch = "CV"+cedula+".txt";
                    if(!carpeta.exists()){
                        carpeta.mkdir();
                    }
                    ArchivoGrabacion arch = new ArchivoGrabacion(System.getProperty("user.dir")+File.separator+"cvs"+"/"+nombreArch);
                    arch.grabarLinea(curriculum);
                    arch.cerrar();
                    limpiarCampos();
                }else{
                    campoSueldo.setText("");
                    JOptionPane.showMessageDialog(this,"EL ÁREA SELECCIONADA NO TIENE SUFICIENTE PRESUPUESTO","ERROR AL INGRESAR",2);
                    
                }
            }
        }catch(NumberFormatException e){
            JOptionPane.showMessageDialog(this,"INGRESE UN SUELDO VALIDO","ERROR AL INGRESAR",2);
            campoSueldo.setText("");
        }
    }//GEN-LAST:event_botonAgregarActionPerformed

    @Override
    public void update(Observable o, Object arg) {
        Empleado emp= (Empleado)listaEmpleados.getSelectedValue();
        cargarListas();
        if(emp!=null){
            for(int i=0;i<modelo.getListaEmpleados().size();i++){
                if(modelo.getListaEmpleados().get(i).getCedula().equalsIgnoreCase(emp.getCedula())){
                    listaEmpleados.setSelectedIndex(i);
                }
            }
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonAgregar;
    private javax.swing.JTextField campoCedula;
    private javax.swing.JTextField campoCelular;
    private javax.swing.JTextField campoCurriculum;
    private javax.swing.JTextField campoNombre;
    private javax.swing.JTextField campoSueldo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel labelArea;
    private javax.swing.JLabel labelCedula;
    private javax.swing.JLabel labelCelular;
    private javax.swing.JLabel labelManager;
    private javax.swing.JLabel labelNombre;
    private javax.swing.JLabel labelNombre2;
    private javax.swing.JLabel labelNombre3;
    private javax.swing.JLabel labelNombre4;
    private javax.swing.JLabel labelNombre5;
    private javax.swing.JLabel labelNombre6;
    private javax.swing.JLabel labelNombre7;
    private javax.swing.JLabel labelNombre8;
    private javax.swing.JLabel labelSueldo;
    private javax.swing.JList listaAreas;
    private javax.swing.JList listaEmpleados;
    private javax.swing.JList listaManagers;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;
}
