package interfaz;
import dominio.*;
//Lucas Villamil (352138) y Dante Puerto (360160)
public class VentanaComenzar extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaComenzar.class.getName());

    public VentanaComenzar() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Comenzar con...");
        setAlwaysOnTop(true);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jPanel1 = new javax.swing.JPanel();
        botonNuevo = new javax.swing.JButton();
        botonGuardado = new javax.swing.JButton();
        botonPrecargados = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 102));

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));
        jPanel1.setLayout(new java.awt.GridBagLayout());

        botonNuevo.setBackground(new java.awt.Color(153, 153, 153));
        botonNuevo.setForeground(new java.awt.Color(0, 0, 0));
        botonNuevo.setText("Sistema nuevo");
        botonNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonNuevoActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 8;
        gridBagConstraints.ipady = 12;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(73, 15, 0, 0);
        jPanel1.add(botonNuevo, gridBagConstraints);

        botonGuardado.setBackground(new java.awt.Color(153, 153, 153));
        botonGuardado.setForeground(new java.awt.Color(0, 0, 0));
        botonGuardado.setText("Sistema guardado");
        botonGuardado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardadoActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.ipadx = 6;
        gridBagConstraints.ipady = 12;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(73, 26, 0, 0);
        jPanel1.add(botonGuardado, gridBagConstraints);

        botonPrecargados.setBackground(new java.awt.Color(153, 153, 153));
        botonPrecargados.setForeground(new java.awt.Color(0, 0, 0));
        botonPrecargados.setText("Sistema con datos precargados");
        botonPrecargados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPrecargadosActionPerformed(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridheight = 2;
        gridBagConstraints.ipadx = 6;
        gridBagConstraints.ipady = 14;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.insets = new java.awt.Insets(72, 28, 89, 39);
        jPanel1.add(botonPrecargados, gridBagConstraints);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 572, 206);
    }// </editor-fold>//GEN-END:initComponents

    private void botonNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonNuevoActionPerformed
        Sistema sis= new Sistema();
        VentanaMenu vent = new VentanaMenu(sis);
        this.dispose();
        vent.setVisible(true);
    }//GEN-LAST:event_botonNuevoActionPerformed

    private void botonGuardadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonGuardadoActionPerformed

    private void botonPrecargadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPrecargadosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonPrecargadosActionPerformed



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonGuardado;
    private javax.swing.JButton botonNuevo;
    private javax.swing.JButton botonPrecargados;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
