package interfaz;
import dominio.*;
public class VentanaComenzar extends javax.swing.JFrame {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaComenzar.class.getName());

    public VentanaComenzar() {
        initComponents();
        this.setLocationRelativeTo(null);
        this.setTitle("Comenzar con...");
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        botonNuevo = new javax.swing.JButton();
        botonGuardado = new javax.swing.JButton();
        botonPrecargados = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(102, 102, 102));

        jPanel1.setBackground(new java.awt.Color(102, 102, 102));

        botonNuevo.setBackground(new java.awt.Color(153, 153, 153));
        botonNuevo.setForeground(new java.awt.Color(0, 0, 0));
        botonNuevo.setText("Sistema nuevo");
        botonNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonNuevoActionPerformed(evt);
            }
        });

        botonGuardado.setBackground(new java.awt.Color(153, 153, 153));
        botonGuardado.setForeground(new java.awt.Color(0, 0, 0));
        botonGuardado.setText("Sistema guardado");
        botonGuardado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGuardadoActionPerformed(evt);
            }
        });

        botonPrecargados.setBackground(new java.awt.Color(153, 153, 153));
        botonPrecargados.setForeground(new java.awt.Color(0, 0, 0));
        botonPrecargados.setText("Sistema con datos precargados");
        botonPrecargados.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonPrecargadosActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(botonNuevo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(26, 26, 26)
                .addComponent(botonGuardado, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(28, 28, 28)
                .addComponent(botonPrecargados, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(39, 39, 39))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonGuardado, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(botonPrecargados, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                    .addComponent(botonNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(91, 91, 91))
        );

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 572, 206);
    }// </editor-fold>//GEN-END:initComponents

    private void botonNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonNuevoActionPerformed
        Sistema sis= new Sistema();
        VentanaMenu vent = new VentanaMenu(sis);
        this.dispose();
        vent.setVisible(true);
    }//GEN-LAST:event_botonNuevoActionPerformed

    private void botonGuardadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGuardadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonGuardadoActionPerformed

    private void botonPrecargadosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonPrecargadosActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_botonPrecargadosActionPerformed



    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonGuardado;
    private javax.swing.JButton botonNuevo;
    private javax.swing.JButton botonPrecargados;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
