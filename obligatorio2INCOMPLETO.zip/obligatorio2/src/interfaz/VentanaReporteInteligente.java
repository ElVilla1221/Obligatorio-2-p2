package interfaz;
import dominio.*;
import java.util.*;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class VentanaReporteInteligente extends javax.swing.JFrame implements Observer{
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaReporteInteligente.class.getName());

    public VentanaReporteInteligente(Sistema sis) {
        initComponents();
        setAlwaysOnTop(true);
        setTitle("Reporte inteligente");
        modelo=sis;
        modelo.addObserver(this);
        cargarListas();
        listaEmpleados.setListData(new Object[0]);
    }
    public void cargarListas(){
        listaOrigen.setListData(modelo.getListaAreas().toArray());
        listaDestino.setListData(modelo.getListaAreas().toArray());
    }
    public void cargarListaEmpleados(Area a){
        listaEmpleados.setListData(a.getListaEmpleados().toArray());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaOrigen = new javax.swing.JList();
        jScrollPane3 = new javax.swing.JScrollPane();
        listaDestino = new javax.swing.JList();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaEmpleados = new javax.swing.JList();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        botonGenerar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        listaOrigen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaOrigen.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaOrigen.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaOrigenValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(listaOrigen);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(20, 50, 150, 210);

        listaDestino.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaDestino.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaDestino.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaDestinoValueChanged(evt);
            }
        });
        jScrollPane3.setViewportView(listaDestino);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(270, 50, 150, 210);

        listaEmpleados.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaEmpleados.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listaEmpleados);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(500, 50, 150, 210);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Área de origen:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 0, 150, 50);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Área de destino:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(270, 0, 150, 50);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Empleados:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(500, 0, 150, 50);

        botonGenerar.setBackground(new java.awt.Color(0, 204, 204));
        botonGenerar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonGenerar.setForeground(new java.awt.Color(0, 0, 0));
        botonGenerar.setText("Generar reporte");
        botonGenerar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonGenerarActionPerformed(evt);
            }
        });
        jPanel1.add(botonGenerar);
        botonGenerar.setBounds(290, 290, 150, 40);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 745, 574);
    }// </editor-fold>//GEN-END:initComponents

    private void listaOrigenValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaOrigenValueChanged
        Area orig = (Area)listaOrigen.getSelectedValue();
        Area dest = (Area)listaDestino.getSelectedValue();
        if(orig!=null && dest!=null){
            if(dest.equals(orig)){
                listaOrigen.clearSelection();
            }
        }
        if(orig!=null){
            cargarListaEmpleados(orig);
        }else{
            listaEmpleados.setListData(new Object[0]);
        }
    }//GEN-LAST:event_listaOrigenValueChanged

    private void listaDestinoValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaDestinoValueChanged
        Area orig = (Area)listaOrigen.getSelectedValue();
        Area dest = (Area)listaDestino.getSelectedValue();
        if(orig!=null && dest!=null){
            if(dest.equals(orig)){
                listaDestino.clearSelection();
            }
        }
    }//GEN-LAST:event_listaDestinoValueChanged

    private void botonGenerarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonGenerarActionPerformed
        
    }//GEN-LAST:event_botonGenerarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonGenerar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JList listaDestino;
    private javax.swing.JList listaEmpleados;
    private javax.swing.JList listaOrigen;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;

    @Override
    public void update(Observable o, Object arg) {
        Area area= (Area)listaOrigen.getSelectedValue();
        cargarListas();
        if(area!=null){
            for(int i=0;i<modelo.getListaAreas().size();i++){
                if(area.getNombre().equalsIgnoreCase(modelo.getListaAreas().get(i).getNombre())){
                    listaOrigen.setSelectedIndex(i);
                    cargarListaEmpleados(area);
                }
            }
        }
    }
}

