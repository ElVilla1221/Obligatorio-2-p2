package interfaz;
import dominio.*;
import java.util.*;
import javax.swing.*;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class VentanaMovimiento extends javax.swing.JFrame implements Observer{
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaMovimiento.class.getName());

    public VentanaMovimiento(Sistema sistema) {
        initComponents();
        setAlwaysOnTop(true);
        setTitle("Realizar movimiento");
        modelo=sistema;
        modelo.addObserver(this);
        cargarListas();
        listaEmpleados.setListData(new Object[0]);
    }
    public void cargarListas(){
        listaOrigen.setListData(modelo.getListaAreas().toArray());
        listaDestino.setListData(modelo.getListaAreas().toArray());
    }
    public void cargarListaEmpleados(Area a){
        listaEmpleados.setListData(a.getListaEmpleados().toArray());
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        comboMes = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaEmpleados = new javax.swing.JList();
        jScrollPane2 = new javax.swing.JScrollPane();
        listaOrigen = new javax.swing.JList();
        jScrollPane3 = new javax.swing.JScrollPane();
        listaDestino = new javax.swing.JList();
        botonMover = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Empleados:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(420, 100, 150, 50);

        comboMes.setBackground(new java.awt.Color(0, 0, 204));
        comboMes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        comboMes.setForeground(new java.awt.Color(255, 255, 255));
        comboMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Enero", "Febrero", "Marzo", "Abril ", "Mayo ", "Junio", "Julio ", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" }));
        jPanel1.add(comboMes);
        comboMes.setBounds(480, 50, 90, 30);

        listaEmpleados.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaEmpleados.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listaEmpleados);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(420, 140, 150, 170);

        listaOrigen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaOrigen.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaOrigen.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaOrigenValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(listaOrigen);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(20, 50, 150, 330);

        listaDestino.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaDestino.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        listaDestino.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                listaDestinoValueChanged(evt);
            }
        });
        jScrollPane3.setViewportView(listaDestino);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(220, 50, 150, 330);

        botonMover.setBackground(new java.awt.Color(0, 0, 153));
        botonMover.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonMover.setForeground(new java.awt.Color(255, 255, 255));
        botonMover.setText("Confirmar movimiento");
        botonMover.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonMoverActionPerformed(evt);
            }
        });
        jPanel1.add(botonMover);
        botonMover.setBounds(400, 350, 200, 40);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 0));
        jLabel2.setText("MES: ");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(420, 40, 50, 50);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(0, 0, 0));
        jLabel3.setText("Área de origen:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 0, 150, 50);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 0, 0));
        jLabel4.setText("Área de destino:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(220, 0, 150, 50);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 654, 455);
    }// </editor-fold>//GEN-END:initComponents

    private void botonMoverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonMoverActionPerformed
        Area orig = (Area)listaOrigen.getSelectedValue();
        Area dest = (Area)listaDestino.getSelectedValue();
        Empleado empl = (Empleado)listaEmpleados.getSelectedValue();
        int mes = comboMes.getSelectedIndex()+1;
        if(orig!=null && dest!=null && empl != null && !orig.equals(dest)){
            if(modelo.puedoMover(empl.getSueldoMensual(), dest, mes)){
                modelo.moverEmpleado(empl, orig, dest, mes);
                modelo.agregarMovimiento(new Movimiento(mes,orig,dest,empl));
                cargarListas();
                listaOrigen.clearSelection();
                listaDestino.clearSelection();
                listaEmpleados.clearSelection();
            }else{
                listaDestino.clearSelection();
                JOptionPane.showMessageDialog(this,"EL ÁREA SELECCIONADA NO TIENE SUFICIENTE PRESUPUESTO","ERROR AL REALIZAR MOVIMIENTO",2); 
            }
        }
    }//GEN-LAST:event_botonMoverActionPerformed

    private void listaOrigenValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaOrigenValueChanged
        Area orig = (Area)listaOrigen.getSelectedValue();
        Area dest = (Area)listaDestino.getSelectedValue();
        if(orig!=null && dest!=null){
            if(dest.getNombre().equalsIgnoreCase(orig.getNombre())){
                listaOrigen.clearSelection();
            }
        }
        if(orig!=null){
            cargarListaEmpleados(orig);
        }else{
            listaEmpleados.setListData(new Object[0]);
        }
    }//GEN-LAST:event_listaOrigenValueChanged

    private void listaDestinoValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_listaDestinoValueChanged
        Area orig = (Area)listaOrigen.getSelectedValue();
        Area dest = (Area)listaDestino.getSelectedValue();
        if(orig!=null && dest!=null){
            if(dest.getNombre().equalsIgnoreCase(orig.getNombre())){
                listaDestino.clearSelection();
            }
        }
    }//GEN-LAST:event_listaDestinoValueChanged

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonMover;
    private javax.swing.JComboBox<String> comboMes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JList listaDestino;
    private javax.swing.JList listaEmpleados;
    private javax.swing.JList listaOrigen;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;

    @Override
    public void update(Observable o, Object arg) {
        Area area= (Area)listaOrigen.getSelectedValue();
        cargarListas();
        if(area!=null){
            for(int i=0;i<modelo.getListaAreas().size();i++){
                if(area.getNombre().equalsIgnoreCase(modelo.getListaAreas().get(i).getNombre())){
                    listaOrigen.setSelectedIndex(i);
                    cargarListaEmpleados(area);
                }
            }
        }
    }
}
