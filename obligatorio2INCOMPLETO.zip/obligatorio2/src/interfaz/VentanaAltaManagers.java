package interfaz;
import dominio.*;
import java.util.*;
import javax.swing.JOptionPane;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class VentanaAltaManagers extends javax.swing.JFrame implements Observer {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaAltaManagers.class.getName());

    public VentanaAltaManagers(Sistema sis) {
        initComponents();
        setTitle("Agregar manager");
        modelo=sis;
        modelo.addObserver(this);
        setAlwaysOnTop(true);
        cargarLista();
    }
    public void limpiarCampos(){
        campoNombre.setText("");
        campoCedula.setText("");
        campoCelular.setText("");
        campoAnt.setText("");
    }
    public void cargarLista(){
        listaManagers.setListData(modelo.getListaManagers().toArray());
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        listaManagers = new javax.swing.JList();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        campoAnt = new javax.swing.JTextField();
        campoNombre = new javax.swing.JTextField();
        campoCedula = new javax.swing.JTextField();
        campoCelular = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        listaManagers.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        listaManagers.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(listaManagers);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(20, 50, 200, 290);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Antigüedad:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(290, 220, 90, 40);

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Nombre:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(290, 50, 90, 40);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Cédula:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(290, 110, 90, 40);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Celular:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(290, 170, 90, 40);

        campoAnt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoAnt);
        campoAnt.setBounds(380, 220, 240, 30);

        campoNombre.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoNombre);
        campoNombre.setBounds(380, 52, 240, 30);

        campoCedula.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoCedula);
        campoCedula.setBounds(380, 110, 240, 30);

        campoCelular.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(campoCelular);
        campoCelular.setBounds(380, 170, 240, 30);

        jButton1.setBackground(new java.awt.Color(0, 0, 204));
        jButton1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButton1.setForeground(new java.awt.Color(255, 255, 255));
        jButton1.setText("Agregar manager");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1);
        jButton1.setBounds(350, 290, 170, 50);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 653, 395);
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String nombre=campoNombre.getText();
        String cedula = campoCedula.getText();
        String celular =campoCelular.getText();
        int antiguedad=0;
        boolean ok=false;
        try{
            antiguedad = Integer.parseInt(campoAnt.getText());
            if(antiguedad<0){
                JOptionPane.showMessageDialog(this,"INGRESE UN NÚMERO VÁLIDO EN LA ANTIGÜEDAD","ERROR AL INGRESAR",2); 
                campoAnt.setText("");
            }else{
                ok=true;
            }
        }catch(NumberFormatException e){
            campoAnt.setText("");
            JOptionPane.showMessageDialog(this,"INGRESE UN NÚMERO VÁLIDO EN LA ANTIGÜEDAD","ERROR AL INGRESAR",2);
        }
        if(ok){
            if(nombre.equals("") || cedula.equals("") || celular.equals("") || campoAnt.getText().equals("")){
                JOptionPane.showMessageDialog(this,"POR FAVOR COMPLETE TODOS LOS CAMPOS","ERROR AL INGRESAR",2);
            }else{
                if(modelo.cedulaValida(cedula)){
                    modelo.agregarManager(new Manager(nombre,cedula,celular,antiguedad));
                    limpiarCampos();
                }
            }
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField campoAnt;
    private javax.swing.JTextField campoCedula;
    private javax.swing.JTextField campoCelular;
    private javax.swing.JTextField campoNombre;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JList listaManagers;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;

    @Override
    public void update(Observable o, Object arg) {
        cargarLista();
    }
}
