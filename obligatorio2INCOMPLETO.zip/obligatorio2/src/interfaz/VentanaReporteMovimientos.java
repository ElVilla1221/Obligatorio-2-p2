package interfaz;
import dominio.*;
import java.util.*;
import javax.swing.table.*;

public class VentanaReporteMovimientos extends javax.swing.JFrame implements Observer {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaReporteMovimientos.class.getName());

    public VentanaReporteMovimientos(Sistema sistema) {
        initComponents();
        tablaMovimientos.getTableHeader().setReorderingAllowed(false);
        grupoBotones();
        modelo=sistema;
        setAlwaysOnTop(true);
        setTitle("Reporte de movimientos");
        modelo.addObserver(this);
        cargarTabla();
        
    }
    public void cargarTabla(){
        DefaultTableModel modeloTabla = (DefaultTableModel)tablaMovimientos.getModel();
        modeloTabla.setRowCount(0);
        for(Movimiento m: modelo.getListaMovimientos()){
            modeloTabla.addRow(new Object[]{m.getMes(),m.getOrigen(),m.getDestino(),m.getEmpleado()});
        }
    }
    public void grupoBotones(){ 
        grupoFiltros.add(opcionMes);
        grupoFiltros.add(opcionDestino);
        grupoFiltros.add(opcionOrigen);
        grupoFiltros.add(opcionEmpleado);
        grupoFiltros.add(sinFiltros);
        sinFiltros.setSelected(true);
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        grupoFiltros = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaMovimientos = new javax.swing.JTable();
        tablaMovimientos.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD,14));
        jLabel1 = new javax.swing.JLabel();
        opcionMes = new javax.swing.JRadioButton();
        opcionOrigen = new javax.swing.JRadioButton();
        opcionDestino = new javax.swing.JRadioButton();
        opcionEmpleado = new javax.swing.JRadioButton();
        sinFiltros = new javax.swing.JRadioButton();
        comboMes = new javax.swing.JComboBox<>();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        tablaMovimientos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tablaMovimientos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tablaMovimientos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mes", "Origen", "Destino", "Empleado"
            }
        ));
        jScrollPane1.setViewportView(tablaMovimientos);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(0, 0, 460, 402);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Filtrar por:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(470, 10, 100, 30);

        opcionMes.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        opcionMes.setText("Mes");
        jPanel1.add(opcionMes);
        opcionMes.setBounds(470, 40, 98, 21);

        opcionOrigen.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        opcionOrigen.setText("Origen");
        jPanel1.add(opcionOrigen);
        opcionOrigen.setBounds(470, 70, 98, 21);

        opcionDestino.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        opcionDestino.setText("Destino");
        jPanel1.add(opcionDestino);
        opcionDestino.setBounds(470, 100, 98, 21);

        opcionEmpleado.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        opcionEmpleado.setText("Empleado");
        jPanel1.add(opcionEmpleado);
        opcionEmpleado.setBounds(470, 130, 90, 21);

        sinFiltros.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        sinFiltros.setText("Sin filtros");
        jPanel1.add(sinFiltros);
        sinFiltros.setBounds(470, 160, 90, 21);

        comboMes.setBackground(new java.awt.Color(0, 0, 204));
        comboMes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        comboMes.setForeground(new java.awt.Color(255, 255, 255));
        comboMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Enero", "Febrero", "Marzo", "Abril ", "Mayo ", "Junio", "Julio ", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" }));
        jPanel1.add(comboMes);
        comboMes.setBounds(540, 40, 90, 20);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 747, 410);
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> comboMes;
    private javax.swing.ButtonGroup grupoFiltros;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton opcionDestino;
    private javax.swing.JRadioButton opcionEmpleado;
    private javax.swing.JRadioButton opcionMes;
    private javax.swing.JRadioButton opcionOrigen;
    private javax.swing.JRadioButton sinFiltros;
    private javax.swing.JTable tablaMovimientos;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;

    @Override
    public void update(Observable o, Object arg) {
        cargarTabla();
    }
}
