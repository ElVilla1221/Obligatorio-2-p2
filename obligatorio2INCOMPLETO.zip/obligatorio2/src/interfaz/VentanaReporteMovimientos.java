package interfaz;
import dominio.*;
import java.util.*;
import javax.swing.table.*;

public class VentanaReporteMovimientos extends javax.swing.JFrame implements Observer {
    
    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(VentanaReporteMovimientos.class.getName());

    public VentanaReporteMovimientos(Sistema sistema) {
        initComponents();
        tablaMovimientos.getTableHeader().setReorderingAllowed(false);
        modelo=sistema;
        setAlwaysOnTop(true);
        setTitle("Reporte de movimientos");
        modelo.addObserver(this);
        cargarTabla();
        cargarCombosAreas();
        cargarComboEmpleados();
        
    }
    public void cargarCombosAreas(){
        comboDestino.removeAllItems();
        comboOrigen.removeAllItems();
        for(Area a: modelo.getListaAreas()){
            comboDestino.addItem(a);
            comboOrigen.addItem(a);
        }
    }
    public void cargarComboEmpleados(){
        comboEmpleados.removeAllItems();
        for(Empleado e: modelo.getListaEmpleados()){           
            comboEmpleados.addItem(e);
        }
    }
    public void cargarTabla(){
        DefaultTableModel modeloTabla = (DefaultTableModel)tablaMovimientos.getModel();
        modeloTabla.setRowCount(0);
        for(Movimiento m: modelo.getListaMovimientos()){
            modeloTabla.addRow(new Object[]{m.getMes(),m.getOrigen(),m.getDestino(),m.getEmpleado()});
        }
    }
    public void aplicarFiltros(){
        DefaultTableModel modeloTabla = (DefaultTableModel)tablaMovimientos.getModel();
        modeloTabla.setRowCount(0);
        for(Movimiento m: modelo.getListaMovimientos()){
            boolean cumple=true;
            if(cumple && checkMes.isSelected()){
                if(!(comboMes.getSelectedIndex()!=-1 && comboMes.getSelectedIndex()+1==m.getMes())){
                    cumple=false;
                }
            }
            if(cumple && checkOrigen.isSelected()){
                if(!(comboOrigen.getSelectedItem()!=null && comboOrigen.getSelectedItem().equals(m.getOrigen()))){
                    cumple=false;
                }
            }
            if(cumple && checkDestino.isSelected()){
                if(!(comboDestino.getSelectedItem()!=null && comboDestino.getSelectedItem().equals(m.getDestino()))){
                    cumple=false;
                }
            }
            if(cumple &&checkEmpleado.isSelected()){
                if(!(comboEmpleados.getSelectedItem()!=null && comboEmpleados.getSelectedItem().equals(m.getEmpleado()))){
                    cumple=false;
                }
            }
            if(cumple){
                modeloTabla.addRow(new Object[]{m.getMes(),m.getOrigen(),m.getDestino(),m.getEmpleado()});
            }
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablaMovimientos = new javax.swing.JTable();
        tablaMovimientos.getTableHeader().setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD,14));
        jLabel1 = new javax.swing.JLabel();
        comboMes = new javax.swing.JComboBox<>();
        comboDestino = new javax.swing.JComboBox();
        comboOrigen = new javax.swing.JComboBox();
        comboEmpleados = new javax.swing.JComboBox();
        checkMes = new javax.swing.JCheckBox();
        checkDestino = new javax.swing.JCheckBox();
        checkOrigen = new javax.swing.JCheckBox();
        checkEmpleado = new javax.swing.JCheckBox();
        botonLimpiar = new javax.swing.JButton();
        botonExportar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setLayout(null);

        tablaMovimientos.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        tablaMovimientos.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        tablaMovimientos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Mes", "Origen", "Destino", "Empleado"
            }
        ));
        jScrollPane1.setViewportView(tablaMovimientos);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(0, 0, 460, 402);

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 0));
        jLabel1.setText("Filtrar por:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(470, 10, 100, 30);

        comboMes.setBackground(new java.awt.Color(0, 0, 204));
        comboMes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        comboMes.setForeground(new java.awt.Color(255, 255, 255));
        comboMes.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Enero", "Febrero", "Marzo", "Abril ", "Mayo ", "Junio", "Julio ", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre" }));
        jPanel1.add(comboMes);
        comboMes.setBounds(590, 40, 100, 20);

        comboDestino.setBackground(new java.awt.Color(0, 0, 204));
        comboDestino.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(comboDestino);
        comboDestino.setBounds(590, 100, 100, 20);

        comboOrigen.setBackground(new java.awt.Color(0, 0, 204));
        comboOrigen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(comboOrigen);
        comboOrigen.setBounds(590, 70, 100, 20);

        comboEmpleados.setBackground(new java.awt.Color(0, 0, 204));
        comboEmpleados.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(comboEmpleados);
        comboEmpleados.setBounds(590, 130, 100, 20);

        checkMes.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        checkMes.setText("Mes:");
        jPanel1.add(checkMes);
        checkMes.setBounds(470, 40, 70, 24);

        checkDestino.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        checkDestino.setText("Destino:");
        jPanel1.add(checkDestino);
        checkDestino.setBounds(470, 100, 90, 24);

        checkOrigen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        checkOrigen.setText("Origen:");
        jPanel1.add(checkOrigen);
        checkOrigen.setBounds(470, 70, 80, 24);

        checkEmpleado.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        checkEmpleado.setText("Empleado:");
        checkEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkEmpleadoActionPerformed(evt);
            }
        });
        jPanel1.add(checkEmpleado);
        checkEmpleado.setBounds(470, 130, 100, 24);

        botonLimpiar.setBackground(new java.awt.Color(255, 0, 0));
        botonLimpiar.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        botonLimpiar.setText("Limpiar Filtros");
        botonLimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonLimpiarActionPerformed(evt);
            }
        });
        jPanel1.add(botonLimpiar);
        botonLimpiar.setBounds(530, 180, 130, 30);

        botonExportar.setBackground(new java.awt.Color(0, 153, 51));
        botonExportar.setFont(new java.awt.Font("Segoe UI", 3, 14)); // NOI18N
        botonExportar.setText("Expotar tabla");
        jPanel1.add(botonExportar);
        botonExportar.setBounds(530, 280, 130, 40);

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        setBounds(0, 0, 747, 410);
    }// </editor-fold>//GEN-END:initComponents

    private void checkEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkEmpleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkEmpleadoActionPerformed

    private void botonLimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonLimpiarActionPerformed
        checkMes.setSelected(false);
        checkOrigen.setSelected(false);
        checkDestino.setSelected(false);
        checkEmpleado.setSelected(false);
        cargarTabla();
    }//GEN-LAST:event_botonLimpiarActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonExportar;
    private javax.swing.JButton botonLimpiar;
    private javax.swing.JCheckBox checkDestino;
    private javax.swing.JCheckBox checkEmpleado;
    private javax.swing.JCheckBox checkMes;
    private javax.swing.JCheckBox checkOrigen;
    private javax.swing.JComboBox comboDestino;
    private javax.swing.JComboBox comboEmpleados;
    private javax.swing.JComboBox<String> comboMes;
    private javax.swing.JComboBox comboOrigen;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tablaMovimientos;
    // End of variables declaration//GEN-END:variables
    private Sistema modelo;

    @Override
    public void update(Observable o, Object arg) {
        cargarTabla();
        cargarCombosAreas();
        cargarComboEmpleados();
    }
}
