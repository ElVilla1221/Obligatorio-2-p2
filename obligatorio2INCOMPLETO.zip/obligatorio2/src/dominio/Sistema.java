package dominio;
import java.io.Serializable;
import java.util.*;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class Sistema extends Observable implements Serializable{
    private ArrayList<Area> listaAreas;
    private ArrayList<Empleado> listaEmpleados;
    private ArrayList<Manager> listaManagers;
    private ArrayList<String> listaCedulas;
    private ArrayList<Movimiento> listaMovimientos;
    public Sistema(){
        this.listaAreas=new ArrayList<>();
        this.listaEmpleados= new ArrayList<>();
        this.listaManagers= new ArrayList<>();
        this.listaCedulas= new ArrayList<>();
        listaMovimientos= new ArrayList<>();
    }
    public Sistema(ArrayList<Area> listaAreas, ArrayList<Empleado> listaEmpleados, ArrayList<Manager> listaManagers) {
        this.listaAreas = listaAreas;
        this.listaEmpleados = listaEmpleados;
        this.listaManagers = listaManagers;
        listaMovimientos= new ArrayList<>();
        listaCedulas=new ArrayList<>();
        listaAreas.add(new Area("Personal",100000,"Reclutamiento de personal, promociones, gestión de cargos"));
        listaAreas.add(new Area("RRHH",80000,"Relacionamiento en la empresa, organigrama, gestión de equipos"));
        listaAreas.add(new Area("Seguridad",120000,"Seguridad fisica, vigilancia, seguridad informática, protocolos y políticas de seguridad"));
        listaAreas.add(new Area("Comunicación",20000,"Comunicaciones internas, reglas y protocolos, comunicaciones con proveedores y clientes"));
        listaAreas.add(new Area("Marketing",95000,"Acciones planificadas, publicidad en medios masivos, publicidad en redes, gestión de redes"));
        listaManagers.add(new Manager("Ana Martínez", "4.568.369-1","099123456", 10));
        listaManagers.add(new Manager("Ricardo Morales", "3.214.589-3","094121212", 4));
        listaManagers.add(new Manager("Laura Torales", "3.589.257-5","099654321", 1));
        listaManagers.add(new Manager("Juan Pablo Zapata", "4.555.197-7","099202020", 5));
    }
    public boolean puedoAgregarArea(String nombre){
        boolean puedo=true;
        for(int i=0;i<listaAreas.size() && puedo;i++){
            if(nombre.equalsIgnoreCase(listaAreas.get(i).getNombre())){
                puedo=false;
            }
        }
        return puedo;
    }
    public void agregarArea(Area a){
        listaAreas.add(a);
        Collections.sort(listaAreas);
        setChanged();
        notifyObservers();
    }
    public ArrayList<Area> getListaAreas() {
        return listaAreas;
    }

    public ArrayList<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }

    public ArrayList<Manager> getListaManagers() {
        return listaManagers;
    }
    
    public ArrayList<Area> darAreasVacias(){
        ArrayList<Area> vacias=new ArrayList<>();
        for(Area a:listaAreas){
            if(a.areaVacia()){
                vacias.add(a);
            }
        }
        Collections.sort(vacias);
        return vacias;
    }
    public ArrayList<Manager> darManagersSinEmpleados(){
        ArrayList<Manager> vacios=new ArrayList<>();
        for(Manager e:listaManagers){
            if(e.sinEmpleados()){
                vacios.add(e);
            }
        }
        return vacios;
    }
    public void borrarArea(Area unArea){
        Iterator<Area> it = listaAreas.iterator();
        while(it.hasNext()){
            Area a = it.next();
            if(a.getNombre().equalsIgnoreCase(unArea.getNombre())&& a.areaVacia()){
                it.remove();
                setChanged();
                notifyObservers();
            }
        }
    }
    public void modificacion(){
        setChanged();
        notifyObservers();
    }
    public boolean puedoMover(int sueldoMens, Area destino,int mes){
        int sueldoARestar=sueldoMens*mes;
        return destino.getPresupuesto()>=sueldoARestar;
    }
    public void moverEmpleado(Empleado emp,Area origen, Area destino,int mes){
        boolean fin=false;
        Iterator<Empleado> it = origen.getListaEmpleados().iterator();
        while(it.hasNext() && !fin){
            Empleado e=it.next();
            if(e.getCedula().equals(emp.getCedula())){
                destino.recibirMovimiento(e,mes);
                e.setArea(destino);
                origen.setPresupuesto(origen.getPresupuesto()+(emp.getSueldoMensual()*(13-mes)));
                it.remove();
                setChanged();
                notifyObservers();
                fin=true;
            }
        }
    }
    public boolean cedulaValida(String cedula){
        boolean valida=true;
        for(String c:listaCedulas){
            if(cedula.equals(c)){
                valida=false;
            }
        }
        return valida;
    }
    public void agregarEmpleadoAlArea(Area a, Empleado emp){
        a.agregarEmpleadoAlArea(emp);
        setChanged();
        notifyObservers();
    }
    public void agregarEmpleadoAlManager(Manager m, Empleado e){
        m.agregarEmpleadoACargo(e);
        setChanged();
        notifyObservers();
    }
    public void agregarEmpleado(Empleado emp){
        listaEmpleados.add(emp);
        listaCedulas.add(emp.getCedula());
        Collections.sort(listaEmpleados);
        setChanged();
        notifyObservers();
    }

    public ArrayList<Movimiento> getListaMovimientos() {
        return listaMovimientos;
    }
    public void agregarMovimiento(Movimiento mov){
        listaMovimientos.add(mov);
        Collections.sort(listaMovimientos);
        setChanged();
        notifyObservers();
    }
    public void agregarManager(Manager m){
        listaManagers.add(m);
        listaCedulas.add(m.getCedula());
        Collections.sort(listaManagers);
        setChanged();
        notifyObservers();
    }
    public void borrarManager(Manager man){
        Iterator<Manager> it = listaManagers.iterator();
        while(it.hasNext()){
            Manager m = it.next();
            if(m.equals(man) && m.sinEmpleados()){
                it.remove();
                setChanged();
                notifyObservers();
            }
        }
    }
    
}
