package dominio;
import java.io.Serializable;
import java.util.*;
//Lucas Villamil (352138) y Dante Puerto (360160)

public class Sistema extends Observable implements Serializable{
    private ArrayList<Area> listaAreas;
    private ArrayList<Empleado> listaEmpleados;
    private ArrayList<Manager> listaManagers;
    private ArrayList<String> listaCedulas;
    private ArrayList<Movimiento> listaMovimientos;
    public Sistema(){
        this.listaAreas=new ArrayList<>();
        this.listaEmpleados= new ArrayList<>();
        this.listaManagers= new ArrayList<>();
        this.listaCedulas= new ArrayList<>();
        listaMovimientos= new ArrayList<>();
        ArrayList<Empleado> hola= new ArrayList<>();
        listaManagers.add(new Manager("Lucas","55555555","091444444",2,hola));
    }
    public Sistema(ArrayList<Area> listaAreas, ArrayList<Empleado> listaEmpleados, ArrayList<Manager> listaManagers) {
        this.listaAreas = listaAreas;
        this.listaEmpleados = listaEmpleados;
        this.listaManagers = listaManagers;
    }
    public boolean puedoAgregarArea(String nombre){
        boolean puedo=true;
        for(int i=0;i<listaAreas.size() && puedo;i++){
            if(nombre.equalsIgnoreCase(listaAreas.get(i).getNombre())){
                puedo=false;
            }
        }
        return puedo;
    }
    public void agregarArea(Area a){
        listaAreas.add(a);
        Collections.sort(listaAreas);
        setChanged();
        notifyObservers();
    }
    public ArrayList<Area> getListaAreas() {
        return listaAreas;
    }

    public ArrayList<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }

    public ArrayList<Manager> getListaManagers() {
        return listaManagers;
    }
    
    public ArrayList<Area> darAreasVacias(){
        ArrayList<Area> vacias=new ArrayList<>();
        for(Area a:listaAreas){
            if(a.areaVacia()){
                vacias.add(a);
            }
        }
        Collections.sort(vacias);
        return vacias;
    }
    public ArrayList<Manager> darManagersSinEmpleados(){
        ArrayList<Manager> vacios=new ArrayList<>();
        for(Manager e:listaManagers){
            if(e.sinEmpleados()){
                vacios.add(e);
            }
        }
        return vacios;
    }
    public void borrarArea(Area unArea){
        Iterator<Area> it = listaAreas.iterator();
        while(it.hasNext()){
            Area a = it.next();
            if(a.getNombre().equalsIgnoreCase(unArea.getNombre())&& a.areaVacia()){
                it.remove();
                setChanged();
                notifyObservers();
            }
        }
    }
    public void modificarArea(Area unArea){
        for(Area a:listaAreas){
            if(a.getNombre().equalsIgnoreCase(unArea.getNombre())){
                a.setDescripcion(unArea.getDescripcion());
                setChanged();
                notifyObservers();
            }
        }
    }
    public boolean puedoMover(int sueldoMens, Area destino,int mes){
        int sueldoARestar=sueldoMens*mes;
        return destino.getPresupuesto()>=sueldoARestar;
    }
    public void moverEmpleado(Empleado emp,Area origen, Area destino,int mes){
        boolean fin=false;
        Iterator<Empleado> it = origen.getListaEmpleados().iterator();
        while(it.hasNext() && !fin){
            Empleado e=it.next();
            if(e.getCedula().equals(emp.getCedula())){
                destino.recibirMovimiento(e,mes);
                e.setArea(destino);
                origen.setPresupuesto(origen.getPresupuesto()+(emp.getSueldoMensual()*(13-mes)));
                it.remove();
                setChanged();
                notifyObservers();
                fin=true;
            }
        }
    }
    public boolean cedulaValida(String cedula){
        boolean valida=true;
        for(String c:listaCedulas){
            if(cedula.equals(c)){
                valida=false;
            }
        }
        return valida;
    }
    public void agregarEmpleadoAlArea(Area a, Empleado emp){
        a.agregarEmpleadoAlArea(emp);
        setChanged();
        notifyObservers();
    }
    public void agregarEmpleado(Empleado emp){
        listaEmpleados.add(emp);
        listaCedulas.add(emp.getCedula());
        Collections.sort(listaEmpleados);
        setChanged();
        notifyObservers();
    }

    public ArrayList<Movimiento> getListaMovimientos() {
        return listaMovimientos;
    }
    public void agregarMovimiento(Movimiento mov){
        listaMovimientos.add(mov);
        Collections.sort(listaMovimientos);
        setChanged();
        notifyObservers();
    }
    
}
