package dominio;
import java.io.Serializable;
import java.util.*;

public class Sistema extends Observable implements Serializable{
    private ArrayList<Area> listaAreas;
    private ArrayList<Empleado> listaEmpleados;
    private ArrayList<Manager> listaManagers;
    public Sistema(){
        this.listaAreas=new ArrayList<>();
        this.listaEmpleados= new ArrayList<>();
        this.listaManagers= new ArrayList<>();
    }
    public Sistema(ArrayList<Area> listaAreas, ArrayList<Empleado> listaEmpleados, ArrayList<Manager> listaManagers) {
        this.listaAreas = listaAreas;
        this.listaEmpleados = listaEmpleados;
        this.listaManagers = listaManagers;
    }
    public boolean puedoAgregarArea(String nombre){
        boolean puedo=true;
        for(int i=0;i<listaAreas.size() && puedo;i++){
            if(nombre.equalsIgnoreCase(listaAreas.get(i).getNombre())){
                puedo=false;
            }
        }
        return puedo;
    }
    public void agregarArea(Area a){
        listaAreas.add(a);
        Collections.sort(listaAreas);
        setChanged();
        notifyObservers();
    }
    public ArrayList<Area> getListaAreas() {
        return listaAreas;
    }

    public ArrayList<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }

    public ArrayList<Manager> getListaManagers() {
        return listaManagers;
    }
    
    public ArrayList<Area> darAreasVacias(){
        ArrayList<Area> vacias=new ArrayList<>();
        for(Area a:listaAreas){
            if(a.areaVacia()){
                vacias.add(a);
            }
        }
        Collections.sort(vacias);
        return vacias;
    }
    public ArrayList<Manager> darManagersSinEmpleados(){
        ArrayList<Manager> vacios=new ArrayList<>();
        for(Manager e:listaManagers){
            if(e.sinEmpleados()){
                vacios.add(e);
            }
        }
        return vacios;
    }
    public void borrarArea(Area unArea){
        Iterator<Area> it = listaAreas.iterator();
        while(it.hasNext()){
            Area a = it.next();
            if(a.getNombre().equalsIgnoreCase(unArea.getNombre())&& a.areaVacia()){
                it.remove();
                setChanged();
                notifyObservers();
            }
        }
    }
    public void modificarArea(Area unArea){
        for(Area a:listaAreas){
            if(a.getNombre().equalsIgnoreCase(unArea.getNombre())){
                a.setDescripcion(unArea.getDescripcion());
                setChanged();
                notifyObservers();
            }
        }
    }
    
}
