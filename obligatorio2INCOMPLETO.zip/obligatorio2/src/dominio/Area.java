package dominio;
import java.io.Serializable;
import java.util.*;
//Lucas Villamil (352138) y Dante Puerto (360160) 

public class Area implements Serializable, Comparable<Area>{
    private String nombre;
    private int presupuesto;
    private String descripcion;
    private ArrayList<Empleado> listaEmpleados;
    public Area(String unNombre, int unPresupuesto, String unaDescripcion){
        this.nombre=unNombre;
        this.presupuesto=unPresupuesto;
        this.descripcion=unaDescripcion;
        listaEmpleados=new ArrayList<>();
    }
    public String getNombre() {
        return nombre;
    }
    public int getPresupuesto() {
        return presupuesto;
    }
    public String getDescripcion() {
        return descripcion;
    }
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    public void setPresupuesto(int presupuesto) {
        this.presupuesto = presupuesto;
    }
    public ArrayList<Empleado> getListaEmpleados() {
        return listaEmpleados;
    }
    public void agregarEmpleadoAlArea(Empleado emp){
        listaEmpleados.add(emp);
        Collections.sort(listaEmpleados);
        this.presupuesto-=emp.getSueldoMensual()*12;
    }
    public boolean areaVacia(){
        return this.getListaEmpleados().isEmpty();
    }
    @Override
    public int compareTo(Area a) {
        return this.getNombre().compareToIgnoreCase(a.getNombre());
    }
    public boolean equals(Area a){
        return this.getNombre().equalsIgnoreCase(a.getNombre());
    }
    @Override
    public String toString() {
        return nombre.toUpperCase();
    }
}
